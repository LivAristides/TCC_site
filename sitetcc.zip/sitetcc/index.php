<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schedule</title>
    <!-- font awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- normalize css -->
    <link rel = "stylesheet" href = "css/normalize.css">
    <!-- custom css -->
    <link rel = "stylesheet" href = "css/style.css">
</head>
<body>
    

    <!-- header -->
    <header class = "header bg-blue">
        <nav class = "navbar bg-blue">
            <div class = "container flex">
                <a href = "index.html" class = "navbar-brand">
                    <img src = "img/icone.png" width="60" height="150" alt = "site logo">
                </a>
                <button type = "button" class = "navbar-show-btn">
                    <img src = "img/ham-menu-icon.png">
                </button>

                <div class = "navbar-collapse bg-white">
                    <button type = "button" class = "navbar-hide-btn">
                        <img src = "img/close-icon.png">
                    </button>
                    <ul class = "navbar-nav">
                        <li class = "nav-item">
                            <a href = "#" class = "nav-link">Home</a>
                        </li>
                        <li class = "nav-item">
                            <a href = "#" class = "nav-link">Sobre</a>
                        </li>
                        <li class = "nav-item">
                            <a href = "#" class = "nav-link">Relevância</a>
                        </li>
                        <li class = "nav-item">
                            <a href = "#" class = "nav-link">Público Alvo</a>
                        </li>
                        <li class = "nav-item">
                            <a href = "#" class = "nav-link">Integrantes</a>
                        </li>
                        <li class = "nav-item">
                            <a href = "#" class = "nav-link">Contato</a>
                        </li>
                    </ul>
                    <div class = "search-bar">
                        <form>
                            <div class = "search-bar-box flex">
                                <span class = "search-icon flex">
                                    <img src = "img/search-icon-dark.png">
                                </span>
                                <input type = "search" class = "search-control" placeholder="Search here">
                            </div>
                        </form>
                    </div>
                </div> 
            </div>
        </nav>

        <div class = "header-inner text-white text-center">
            <div class = "container grid">
                <div class = "header-inner-left">
                    <h1><br> <span>SCHEDULE</span></h1>
                    <p class = "lead">Aplicativo de organização de estudos</p>
                    <p class = "text text-md">Gostaria de saber mais sobre este aplicativo de organização voltado para estudantes?</p>
                    <div class = "btn-group">
                        <a href = "#" class = "btn btn-white">Saiba Mais</a>
                        
                    </div>
                </div>
                <div class = "header-inner-right">
                    <img src = "img/logo.png">
                </div>
            </div>
        </div>
    </header>
    <!-- end of header -->

    <main>
        <!-- about section -->
        <section id = "about" class = "about py">
            <div class = "about-inner">
                <div class = "container grid">
                    <div class = "about-left text-center">
                        <div class = "section-head">
                            <h2>Sobre</h2>
                            <div class = "border-line"></div>
                        </div>
                        <p class = "text text-lg">O Schedule é um aplicativo mobile com base na metodologia ágil Kanban que auxilia no controle e organização de tarefas através de cartões que representam afazeres, possibilitando movê-los entre colunas que correspondem à cada etapa do processo, promovendo aumento de produtividade e melhoria na gestão de tempo dos usuários.</p>
                        
                    </div>
                    <div class = "about-right flex">
                        <div class = "img">
                            <img src = "img/tela 1.png">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of about section -->

        <!-- banner one -->
        <section id = "banner-one" class = "banner-one text-center">
        <div class = "banner-two-left">
                    <img src = "img/tela 1.png">
                </div>
        </section>
        <!-- end of banner one -->

        <!-- services section -->
        <section id = "services" class = "services py">
            <div class = "container">
                <div class = "section-head text-center">
                    <h2 class = "lead">Por que usar o Schedule?</h2>
                    <p class = "text text-lg">Relevâncias do Aplicativo</p>
                    <div class = "line-art flex">
                        <div></div>
                        <img src = "img/4-dots.png">
                        <div></div>
                    </div>
                </div>
                <div class = "services-inner text-center grid">
                    <article class = "service-item">
                        <div class = "icon">
                            <img src = "img/icons8-cronômetro-50.png">
                        </div>
                        <h3>Gerenciamento de Tempo</h3>
                        <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis possimus doloribus facilis velit, assumenda tempora quas mollitia quos voluptatibus consequatur!</p>
                    </article>

                    <article class = "service-item">
                        <div class = "icon">
                            <img src = "img/icons8-gráfico-positivo-50.png">
                        </div>
                        <h3>Produtividade</h3>
                        <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis possimus doloribus facilis velit, assumenda tempora quas mollitia quos voluptatibus consequatur!</p>
                    </article>

                    <article class = "service-item">
                        <div class = "icon">
                            <img src = "img/icons8-colaboração-50.png">
                        </div>
                        <h3>Colaboração Eficiente</h3>
                        <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis possimus doloribus facilis velit, assumenda tempora quas mollitia quos voluptatibus consequatur!</p>
                    </article>

                    <article class = "service-item">
                        <div class = "icon">
                            <img src = "img/icons8-livro-50.png">
                        </div>
                        <h3>Desenvolvimento de Hábitos de Estudos</h3>
                        <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis possimus doloribus facilis velit, assumenda tempora quas mollitia quos voluptatibus consequatur!</p>
                    </article>
                </div>
            </div>
        </section>
        <!-- end of services section -->

        <!-- banner two section -->
        <section id = "banner-two" class = "banner-two text-center">
            <div class = "container grid">
                <div class = "banner-two-left">
                    <img src = "img/splash.png">
                </div>
                <div class = "banner-two-right">
                    <p class = "lead text-white">When you are young and healthy, it never occurs to you that in a single second your whole life could change.</p>
                    <div class = "btn-group">
                        <a href = "#" class = "btn btn-white">Learn More</a>
                        <a href = "#" class = "btn btn-light-blue">Sign In</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- end of banner two section -->

       

        <!-- package services section -->
        <section id = "package-service" class = "package-service py text-center">
            <div class = "container">
                <div class = "package-service-head text-white">
                    <h2>Público Alvo</h2>
                    <p class = "text text-lg"></p>
                </div>
                <div class = "package-service-inner grid">
                    <div class = "package-service-item bg-blue">
                        <div class = "icon flex">
                            <i class = "fas fa-school fa-2x"></i>
                        </div>
                        <h3 class="text-white">Estudantes</h3>
                        <p class = "text text-sm">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consequatur, asperiores. Expedita, reiciendis quos beatae at consequatur voluptatibus fuga iste adipisci.</p>
                        <a href = "#" class = "btn btn-white text-blue">Read More</a>
                    </div>

                    
                </div>
            </div>
        </section>

 <!-- doctors section -->
 <section id = "doc-panel" class = "doc-panel py">
            <div class = "container">
                <div class = "section-head">
                    <h2>Integrantes do Grupo</h2>
                </div>

                <div class = "doc-panel-inner grid">
                    <div class = "doc-panel-item">
                        <div class = "img flex">
                            <img src = "img/livia.jpg" alt = "doctor image">
                            <div class = "info text-center bg-blue text-white flex">
                                <p class = "lead">Lívia Aristides</p>
                                <p class = "text-lg">Líder, Programação e Design</p>
                            </div>
                        </div>
                    </div>

                    <div class = "doc-panel-item">
                        <div class = "img flex">
                            <img src = "img/dani2.jpg" alt = "doctor image">
                            <div class = "info text-center bg-blue text-white flex">
                                <p class = "lead">Daniela Ribas</p>
                                <p class = "text-lg">Documentação e Pesquisas</p>
                            </div>
                        </div>
                    </div>

                    <div class = "doc-panel-item">
                        <div class = "img flex">
                            <img src = "img/arthur.jpg" alt = "doctor image">
                            <div class = "info text-center bg-blue text-white flex">
                                <p class = "lead">Arthur dos Anjos</p>
                                <p class = "text-lg">Programação</p>
                            </div>
                        </div>
                    </div>

                    <div class = "doc-panel-item">
                        <div class = "img flex">
                            <img src = "img/gabi4.jpg" alt = "doctor image">
                            <div class = "info text-center bg-blue text-white flex">
                                <p class = "lead">Gabriela Cardoso</p>
                                <p class = "text-lg">Design e Pesquisa</p>
                            </div>
                        </div>
                    </div>

                    <div class = "doc-panel-item">
                        <div class = "img flex">
                            <img src = "img/ju.jpg" alt = "doctor image">
                            <div class = "info text-center bg-blue text-white flex">
                                <p class = "lead">Juliana Lima</p>
                                <p class = "text-lg">Documentação e Pesquisas</p>
                            </div>
                        </div>
                    </div>

                    <div class = "doc-panel-item">
                        <div class = "img flex">
                            <img src = "img/dani.jpg" alt = "doctor image">
                            <div class = "info text-center bg-blue text-white flex">
                                <p class = "lead">Lucas Souza</p>
                                <p class = "text-lg">Programação</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <!-- end of doctors section -->

        <!-- end of package services section -->

        <!-- posts section -->
       <!-- <section id = "posts" class = "posts py">
            <div class = "container">
                <div class = "section-head">
                    <h2>Latest Post</h2>
                </div>
                <div class = "posts-inner grid">
                    <article class = "post-item bg-white">
                        <div class = "img">
                            <img src = "img/post-1.jpg">
                        </div>
                        <div class = "content">
                            <h4>Inspiring stories of person and family centered care during a global pandemic.</h4>
                            <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolor voluptas eius recusandae sunt obcaecati esse facere cumque. Aliquid, cupiditate debitis.</p>
                            <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis quia ipsam, quis iure sed nulla.</p>
                            <div class = "info flex">
                                <small class = "text text-sm"><i class = "fas fa-clock"></i> October 27, 2021</small>
                                <small class = "text text-sm"><i class = "fas fa-comment"></i> 5 comments</small>
                            </div>
                        </div>
                    </article>

                    <article class = "post-item bg-white">
                        <div class = "img">
                            <img src = "img/post-2.jpg">
                        </div>
                        <div class = "content">
                            <h4>Inspiring stories of person and family centered care during a global pandemic.</h4>
                            <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolor voluptas eius recusandae sunt obcaecati esse facere cumque. Aliquid, cupiditate debitis.</p>
                            <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis quia ipsam, quis iure sed nulla.</p>
                            <div class = "info flex">
                                <small class = "text text-sm"><i class = "fas fa-clock"></i> October 27, 2021</small>
                                <small class = "text text-sm"><i class = "fas fa-comment"></i> 5 comments</small>
                            </div>
                        </div>
                    </article>

                    <article class = "post-item bg-white">
                        <div class = "img">
                            <img src = "img/post-3.jpg">
                        </div>
                        <div class = "content">
                            <h4>Inspiring stories of person and family centered care during a global pandemic.</h4>
                            <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolor voluptas eius recusandae sunt obcaecati esse facere cumque. Aliquid, cupiditate debitis.</p>
                            <p class = "text text-sm">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis quia ipsam, quis iure sed nulla.</p>
                            <div class = "info flex">
                                <small class = "text text-sm"><i class = "fas fa-clock"></i> October 27, 2021</small>
                                <small class = "text text-sm"><i class = "fas fa-comment"></i> 5 comments</small>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section> -->
        
        <!-- end of posts section -->

        <!-- contact section -->
        <section id = "contact" class = "contact py">
            <div class = "container grid">
                <div class = "contact-left">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3664.778617744623!2d-47.29017509999999!3d-23.287492499999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cf5ab2d35d2b0d%3A0x90131a5f0c2272b3!2sEscola%20T%C3%A9cnica%20Estadual%20Martinho%20di%20Ciero%20-%20Itu!5e0!3m2!1spt-BR!2sbr!4v1718154816596!5m2!1spt-BR!2sbr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class = "contact-right text-white text-center bg-blue">
                    <div class = "contact-head">
                        <h3 class = "lead">Contato</h3>
                        <p class = "text text-md">Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga.</p>
                    </div>
                    <form>
                        <div class = "form-element">
                            <input type = "text" class = "form-control" placeholder="Seu nome">
                        </div>
                        <div class = "form-element">
                            <input type = "email" class = "form-control" placeholder="Seu email">
                        </div>
                        <div class = "form-element">
                            <textarea rows = "5" placeholder="Sua mensagem" class = "form-control"></textarea>
                        </div>
                        <button type = "submit" class = "btn btn-white btn-submit">
                            <i class = "fas fa-arrow-right"></i> Enviar Menssagem
                        </button>
                    </form>
                </div>
            </div>
        </section>
        <!-- end of contact section -->
    </main>

    <!-- footer  -->
    <footer id = "footer" class = "footer text-center">
        <div class = "container">
            <div class = "footer-inner text-white py grid">
                <div class = "footer-item">
                    <h3 class = "footer-head">Sobre</h3>
                    <div class = "icon">
                        <img src = "img/icone.png">
                    </div>
                    <p class = "text text-md">O Schedule é um aplicativo mobile com base na metodologia ágil Kanban que auxilia no controle e organização de tarefas através de cartões que representam afazeres, possibilitando movê-los entre colunas que correspondem à cada etapa do processo, promovendo aumento de produtividade e melhoria na gestão de tempo dos usuários.</p>
                   
                </div>

                <div class = "footer-item">
                    <h3 class = "footer-head">tags</h3>
                    <ul class = "tags-list flex">
                        <li>aplicativo mobile</li>
                        <li>estudos</li>
                        <li>organização</li>
                        <li>kanban</li>
                        <li>métodos ágeis</li>
                        
                    </ul>
                </div>

                <div class = "footer-item">
                    <h3 class = "footer-head"> Links</h3>
                    <ul>
                        <li><a href = "#" class = "text-white"></a>Home</li>
                        <li><a href = "#" class = "text-white">Sobre</a></li>
                        <li><a href = "#" class = "text-white">Relevância</a></li>
                        <li><a href = "#" class = "text-white">Público Alvo</a></li>
                        <li><a href = "#" class = "text-white">Integrantes</a></li>
                        <li><a href = "#" class = "text-white">Contato</a></li>
                    </ul>
                </div>

              

            <div class = "footer-links">
                <ul class = "flex">
                    <li><a href = "#" class = "text-white flex"> <i class = "fab fa-facebook-f"></i></a></li>
                    <li><a href = "#" class = "text-white flex"> <i class = "fab fa-twitter"></i></a></li>
                    <li><a href = "#" class = "text-white flex"> <i class = "fab fa-linkedin"></i></a></li>
                </ul>
            </div>
        </div>
    </footer>
    <!-- end of footer  -->


    <!-- custom js -->
    <script src = "js/script.js"></script>
</body>
</html>